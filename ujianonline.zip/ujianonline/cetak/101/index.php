<?php
session_set_cookie_params(0);
session_start();
require('../plugins/fpdf/fpdf.php');

if(!isset($_SESSION['Nama'])){
  header("Location: ../../");
}else{}

$Nama = $_SESSION['Nama'];
$Nis = $_SESSION['Nis'];
$Kelas = $_SESSION['Kelas'];
$Jurusan = $_SESSION['Jurusan'];
$NamaUjian = $_SESSION['Nama_Ujian'];
$JumlahSoal = $_SESSION['Jumlah_Soal'];

include "../connection.php";
$sql = mysqli_query($conn, "SELECT * FROM data_hasil_ujian WHERE Id_Siswa = '$Nis'");
$data = mysqli_fetch_array($sql);
$SoalBenar = $data['3'];
$HasilAkhir = $data['4'];

class PDF extends FPDF{
  function Footer(){
    $this->SetY(-15);
    $this->SetFont('Times','I',8);
    $this->Cell(199,10,'Copyright 2020 CBT Testing - Made by M.Al Fauzy',0,1,'L');
  }
}

$pdf = new PDF('P', 'mm','Letter');
$pdf->AddPage();

$pdf->SetFont('Arial','B',18);
$pdf->Cell(0,7,'Hasil Ujian',0,1,'L');

$pdf->Cell(10,10,'',0,1);

$pdf->SetFont('Arial','',10);
$pdf->Cell(0,7,'Terimakasih Anda telah menyelesaikan Ujian '.$NamaUjian.' dengan sungguh-sungguh,',0,1,'L');
$pdf->Cell(0,2,'Kesuksesan hanya dapat terjadi jika kita berusaha dan mau belajar dari kegagalan.',0,1,'L');
$pdf->Cell(10,5,'',0,1);

$pdf->SetFont('Arial','B',15);
$pdf->Cell(1,7,'Data Peserta',0,1,'L');
$pdf->Cell(10,5,'',0,1);

$pdf->SetFont('Arial','',11);
$pdf->Cell(80,5,'NIS',0,0,'L');
$pdf->Cell(100,5,$Nis,0,1,'L');

$pdf->Cell(80,5,'Nama',0,0,'L');
$pdf->Cell(100,5,$Nama,0,1,'L');

$pdf->Cell(80,5,'Kelas',0,0,'L');
$pdf->Cell(100,5,$Kelas,0,1,'L');

$pdf->Cell(80,5,'Jurusan',0,0,'L');
$pdf->Cell(100,5,$Jurusan,0,1,'L');
$pdf->Cell(10,5,'',0,1);
$pdf->SetFont('Arial','B',15);
$pdf->Cell(1,7,'Data Ujian',0,1,'L');
$pdf->Cell(10,5,'',0,1);

$pdf->SetFont('Arial','',11);
$pdf->Cell(80,5,'Nama Ujian',0,0,'L');
$pdf->Cell(100,5,$NamaUjian,0,1,'L');

$pdf->Cell(80,5,'Jumlah Soal',0,0,'L');
$pdf->Cell(100,5,$JumlahSoal.' soal',0,1,'L');
$pdf->Cell(10,5,'',0,1);
$pdf->SetFont('Arial','B',15);
$pdf->Cell(1,7,'Hasil Ujian',0,1,'L');
$pdf->Cell(10,5,'',0,1);

$pdf->SetFont('Arial','',11);
$pdf->Cell(80,5,'Soal Benar',0,0,'L');
$pdf->Cell(100,5,$SoalBenar.' soal',0,1,'L');

$pdf->Cell(80,5,'Nilai Akhir',0,0,'L');
$pdf->Cell(100,5,$HasilAkhir,0,1,'L');

$pdf->Output('I','Ujian_'.$NamaUjian.'_'.$Kelas.'_'.$Nis.'.pdf');
?>
